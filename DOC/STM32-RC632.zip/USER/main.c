#include "includes.h"
#include "rc632.h"
#include "iso14443a.h"
#include "iso15693.h"



#define PDA_HEAD	    0xA5
#define PDA_COMT_SET	0x57
#define PDA_COMT_REQ	0x52
#define PDA_COMT_AUTO	0x41

#define PACK_HEAD	0
#define PACK_LENG	1
#define PACK_NUMB	2
#define PACK_COMT	3
#define PACK_COMM	4
#define PACK_ACKN	5
#define PACK_DALE	6
#define PACK_DATA	7


unsigned char iso14443a_cardtype[2];
unsigned char iso14443a_cardsnr[4];
unsigned char iso15693_cardsnr[8];
unsigned char iso14443a_buffer[6];
unsigned char iso14443a_Zhe[30];

unsigned char uart_indx, recv_flag;
unsigned char uart_sbuf[50];
unsigned char uart_rbuf[50];

unsigned char PDA_product_ver[] = "EmbedSky PDA MCU-RFID ver0.1";


void PDA_package(unsigned char num, unsigned char com_type,
		 unsigned char com, unsigned char ack,
		 unsigned char len, unsigned char *dat, unsigned char *buf);

unsigned short crc16_table(unsigned char *pcrc, unsigned short cnt);

void uart_putd(unsigned char *d);
		 
void uart_clr(void);
		 
void uart_puts(unsigned char *s);
		 

typedef enum{
   Card_Null,
   Card_AutoType,
   Card_ScanTag,
   Card_ScanCard,
   Card_InitOver,
   Card_ReadOver,
   Card_Recharge,
   Card_Buckle,
   Card_ReadData,
   Card_WriteData,
}Card_Oper;

Card_Oper CARD_OPER = Card_Null,CARD_FLAG = Card_Null;

/* Private defines -----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
uint16_t  led_count = 0;



int main(void)
{
		unsigned char size, len, sta;
		unsigned char coded[12];
		unsigned char dat_buf[16], buf[70];
		unsigned int crc;
		unsigned char par, rst_dat[18];
		unsigned char cos_fwi, cos_cidnad, cos_len;
		unsigned char cos_dat[40];
    unsigned char Key_New[6] = {0x11,0x88,0x12,0x16,0x6D,0x89};

    int i;
	  uint8_t count = 0;
	
		delay_init(72);	    	
		//��ʱ������ʼ��	  
		bsp_InitUart(COM1,115200);
		//�����õĴ���1
	
	  HardWare_Init();
	  
	  for(count = 0; count<10; count++)
    {
			  BUZZER_ONCE();
			  delay_ms(200);
		}
	
		Checki_Sys();
		//���ϵͳƵ��	
		bsp_NVIC_Configuration();
    
		rc_init();
		
		PCD_reset();
	  delay_ms(200);
    
//  PCD_AntennaOFF();
//	delay_ms(5);
	  PCD_cfg_iso_type('A');
	  delay_ms(5);
		
		
		while(1)
	  { 
		    // �Զ�Ѱ��������������ֹͣѰ������
        // Э��ΪISO14443A��ִ��һ�ζ������ͺͶ����Ų���			
				if(CARD_OPER != Card_Null && recv_flag == 0)
				{                       
						CARD_FLAG = CARD_OPER;
						sta = MI_OK;
						PCD_AntennaOFF();
						delay_ms(3);
						PCD_cfg_iso_type('A');
						delay_ms(3);
						sta = PCD_request(0x52, iso14443a_cardtype);
								
                        
						if (MI_OK == sta) 
						{
								sta = PCD_anticoll(iso14443a_cardsnr);

								if(sta == MI_OK)
								{
										//uart_puts(" 1.CardType ");	
										if(CARD_OPER == Card_AutoType) //Э��ΪISO14443A
										{
												CARD_OPER = Card_Null;
												memcpy(&buf[0], iso14443a_cardtype, 2);
												memcpy(&buf[2], iso14443a_cardsnr, 4);
												PDA_package(0x00, PDA_COMT_AUTO, 'a', 0x00, 6, buf, uart_sbuf);
												
												PCD_AntennaOFF();												
												uart_putd(uart_sbuf);   
												delay_ms(2);
										}
										else if(CARD_OPER == Card_ScanCard)//MF��
										{
												CARD_OPER = Card_Null;
												PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
																						uart_rbuf[PACK_COMM], 0x00,
																						4, iso14443a_cardsnr, uart_sbuf);
												
												PCD_AntennaOFF();												
												uart_putd(uart_sbuf);   
												delay_ms(2);
										}
										else 
										{		
												sta = PCD_select(iso14443a_cardsnr, &size);
												if(MI_OK == sta)
												{
													//uart_puts(" 2.CardSelect ");	                        
													getCardKey(iso14443a_cardsnr,&uart_rbuf[PACK_DATA+2],Key_New);
													change_code_key(Key_New, coded); 		 
													sta = PCD_auth_key(coded);
													 
													if(MI_OK == sta)
													{
															//uart_puts(" 3.CardFillKey ");	
															sta = PCD_auth_state(uart_rbuf[PACK_DATA], uart_rbuf[PACK_DATA+1],
																												 iso14443a_cardsnr);
															if(MI_OK == sta)
															{  
																	//uart_puts(" 4.CardAuthKey ");	
																	
																	if(CARD_OPER == Card_WriteData) 
																	{    
																			if(MI_OK == PCD_write(uart_rbuf[PACK_DATA+1], &uart_rbuf[PACK_DATA+8]))
																			{	
																				 //uart_puts("  5.WriteData  ");
																				 
																				 memcpy(dat_buf,&uart_rbuf[PACK_DATA+8],16);                                           
																				 CARD_OPER = Card_Null; 
																				 PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
																											uart_rbuf[PACK_COMM], 0x00,
																											16, dat_buf, uart_sbuf); 
																			}                                  
																	}
																	else if(CARD_OPER == Card_ReadData)
																	{                                            
																			if(MI_OK == PCD_read(uart_rbuf[PACK_DATA+1], dat_buf))
																			{
																					//uart_puts("  5.ReadData  ");
																					
																					CARD_OPER = Card_Null;   
																					PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
																											uart_rbuf[PACK_COMM], sta,
																											16, dat_buf, uart_sbuf); 
																			}
																	}
																	else if(CARD_OPER == Card_InitOver)
																	{                   
																			if(MI_OK == PCD_val_init(uart_rbuf[PACK_DATA+1], &uart_rbuf[PACK_DATA+8]))
																			{
																				 //uart_puts("  5.InitOver  ");
																				 
																				 CARD_OPER = Card_Null;   
																				 PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
																									 uart_rbuf[PACK_COMM], sta, 4, &uart_rbuf[PACK_DATA+8], uart_sbuf);                             
																			}                                           
																	}
																	else if(CARD_OPER == Card_Recharge)
																	{                                                 
																			if(MI_OK == PCD_value(PICC_INCREMENT, uart_rbuf[PACK_DATA+1], &uart_rbuf[PACK_DATA+8]))
																			{         
																					//uart_puts("  5.Recharge  ");
																					sta = PCD_read(uart_rbuf[PACK_DATA+1], dat_buf);
																					
																					if(MI_OK == sta)
																					{                                                     
																							 CARD_OPER = Card_Null;   
																							 PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
																													 uart_rbuf[PACK_COMM], sta,4, dat_buf, uart_sbuf);  
																					} 
																			}                                            
																	}
																	else if(CARD_OPER == Card_Buckle)//??
																	{
																			if(MI_OK == PCD_value(PICC_DECREMENT, uart_rbuf[PACK_DATA+1], &uart_rbuf[PACK_DATA+8]))
																			{    
																					//uart_puts("  5.Buckle  ");
																					sta = PCD_read(uart_rbuf[PACK_DATA+1], dat_buf);
																					
																					if(MI_OK == sta)
																					{
																							 CARD_OPER = Card_Null;   
																							 PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
																													 uart_rbuf[PACK_COMM], sta,4, dat_buf, uart_sbuf);  
																					}                                                                                                      
																			}
																	}
																	else if(CARD_OPER == Card_ReadOver)//????
																	{
																			sta = PCD_read(uart_rbuf[PACK_DATA+1], dat_buf);
																			
																			if(MI_OK == sta)
																			{
																				 //uart_puts("  5.ReadOver  ");
																				 
																				 CARD_OPER = Card_Null;   
																				 PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
																				 uart_rbuf[PACK_COMM], sta,4, dat_buf, uart_sbuf);   
																			}
																												 
																	}				                                         
															}//��֤��Կ if_end
													 }//�����Կif_end                          
											 }//ѡ��Ƭif_end  
								  }//else end
			        }
	            if(CARD_OPER == Card_Null)
							{    
									uart_putd(uart_sbuf);	
									PCD_AntennaOFF();
								  BUZZER_ON();
									delay_ms(100);
								  BUZZER_OFF();
								
									CARD_OPER = CARD_FLAG;
							}            	
           }
		    }
		
	     	if (recv_flag)  
        {                       
		      	crc = uart_rbuf[uart_rbuf[PACK_LENG]]<<8 | uart_rbuf[uart_rbuf[PACK_LENG]+1];
		      	if (crc == crc16_table(uart_rbuf, uart_rbuf[PACK_LENG])) 
						{
								CARD_OPER = Card_Null;
							  recv_flag = 0;
            } 
            else
            {
								PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
											uart_rbuf[PACK_COMM], 0xFF,
											2, (unsigned char*)&crc, uart_sbuf);
								uart_putd(uart_sbuf);
								
								uart_clr();
								recv_flag = 0;
								uart_indx = 0;
                              
				       continue;
			      }

			      if (uart_rbuf[PACK_COMT] == PDA_COMT_SET) 
            {
			         	sta = 0;

								if(uart_rbuf[PACK_COMM] >= 'A' && uart_rbuf[PACK_COMM] <= 'Z')
								{                                  
											 if(uart_rbuf[PACK_COMM] == 'O') 	
											 {
														CARD_OPER = Card_InitOver;                                                                                          
											 }
											 else if(uart_rbuf[PACK_COMM] == 'C')	
											 {
														CARD_OPER = Card_Recharge; 
											 }
											 else if(uart_rbuf[PACK_COMM] == 'B')	
											 {
														CARD_OPER = Card_Buckle; 
											 }
											 else if(uart_rbuf[PACK_COMM] == 'W')
											 {
														CARD_OPER = Card_WriteData; 
											 }
											 else 
											 {
														PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
														uart_rbuf[PACK_COMM], 0x11, 0, 0, uart_sbuf);
											 }                             
								}
								else
								{
										switch (uart_rbuf[PACK_COMM]) 
										{
											case 'd':	
															CARD_OPER = Card_AutoType;
															break;
											case 'l':	
															//PDA_LED_switch(uart_rbuf[PACK_DATA]);
															break;
											case 'b':	
															//PDA_BEEP_soud(uart_rbuf[PACK_DATA], uart_rbuf[PACK_DATA+1]);
															break;
											case 'u':	
															//PDA_UART_baud(uart_rbuf[PACK_DATA]);
															break;
											case 'a':	
															//PDA_ANT_switch(uart_rbuf[PACK_DATA]);
															break;
											case 'i':	
															PCD_AntennaOFF();
															delay_ms(10);
															sta = PCD_cfg_iso_type(uart_rbuf[PACK_DATA]);
															break;
											case 'h':	
															sta = PCD_halt();
															break;
											case 'w':	
															sta = PCD_write(uart_rbuf[PACK_DATA], &uart_rbuf[PACK_DATA+1]);
															break;

											case 'f':	
												      change_code_key(&uart_rbuf[PACK_DATA], coded);
											      	sta = PCD_auth_key(coded);
											       	break;  
															
		                  case 'k':	                                             
															sta = PCD_auth_state(uart_rbuf[PACK_DATA], uart_rbuf[PACK_DATA+1],
																									 &uart_rbuf[PACK_DATA+2]);
															break;
											case 's':	                                             
															sta = PCD_select(&uart_rbuf[PACK_DATA], &size);
															break;
											case 'v':	
															sta = PCD_val_init(uart_rbuf[PACK_DATA], &uart_rbuf[PACK_DATA+1]);
															break;
											case '+':	
															sta = PCD_value(PICC_INCREMENT, uart_rbuf[PACK_DATA], &uart_rbuf[PACK_DATA+1]);
															break;
											case '-':	
															sta = PCD_value(PICC_DECREMENT, uart_rbuf[PACK_DATA], &uart_rbuf[PACK_DATA+1]);
															break;
											default:
															sta = 0x11;
															break; 
										}
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
                    uart_rbuf[PACK_COMM], sta, 0, 0, uart_sbuf);
								}
			       } 
						else if (uart_rbuf[PACK_COMT] == PDA_COMT_REQ) 
						{
								if(uart_rbuf[PACK_COMM] == 'S') 
								{                                       
					          CARD_OPER = Card_ScanCard;
                }
								else if(uart_rbuf[PACK_COMM] == 'T') //���ؿ���
								{      
								    CARD_OPER = Card_ScanTag;   
								}
								else if(uart_rbuf[PACK_COMM] == 'G' || uart_rbuf[PACK_COMM] == 'R')
								{
										 if(uart_rbuf[PACK_COMM] == 'G') //�����
										 {
													CARD_OPER = Card_ReadOver;  
										 }
										 else if(uart_rbuf[PACK_COMM] == 'R') //��������
										 {                                             
													CARD_OPER = Card_ReadData;  	
										 }                                                                            
								}                     
								else if (uart_rbuf[PACK_COMM] == 'p') 
								{		
										len = sizeof(PDA_product_ver);
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
										uart_rbuf[PACK_COMM], 0x00,len, PDA_product_ver, uart_sbuf);                                              
				        } 
								else if (uart_rbuf[PACK_COMM] == 'c') 
								{	
										sta = PCD_request(0x52, iso14443a_cardtype);
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
										uart_rbuf[PACK_COMM], sta,2, iso14443a_cardtype, uart_sbuf);
				        } 
								else if (uart_rbuf[PACK_COMM] == 'n') 
								{	
										sta = PCD_anticoll(iso14443a_cardsnr);
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
										uart_rbuf[PACK_COMM], sta,4, iso14443a_cardsnr, uart_sbuf);
				        } 
								else if (uart_rbuf[PACK_COMM] == 'r') 
								{
										sta = PCD_read(uart_rbuf[PACK_DATA], dat_buf);
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
													uart_rbuf[PACK_COMM], sta,
													16, dat_buf, uart_sbuf);
				        } 
                else if (uart_rbuf[PACK_COMM] == 't') 
                {	// 15693??
										sta = PDA_15693_snr(iso15693_cardsnr);
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
													uart_rbuf[PACK_COMM], sta,
													8, iso15693_cardsnr, uart_sbuf);
										for (i=0; i<8; i++)
						        iso15693_cardsnr[i] = 0x00;
				        } 
                else if (uart_rbuf[PACK_COMM] == '=') 
                {	// ????
										sta = PCD_read(uart_rbuf[PACK_DATA], dat_buf);
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
										uart_rbuf[PACK_COMM], sta, 4, dat_buf, uart_sbuf);
				        } 
                else if (uart_rbuf[PACK_COMM] == 'o') 
                {	// COS??
										par = (4<<4) & 0xF0;
										sta = PCD_mfpro_rst(par, &len, &rst_dat[2]);
										rst_dat[0] = par;
										rst_dat[1] = len;
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
										uart_rbuf[PACK_COMM], sta, 0x12, rst_dat, uart_sbuf);
						    
										cos_fwi = rst_dat[3];
										cos_cidnad = 0;
										for (i=0; i<18; i++)
											rst_dat[i] = 0x00;
				        } 
								else if (uart_rbuf[PACK_COMM] == 'm') 
								{	// ??COS??
										cos_len = uart_rbuf[PACK_DALE];
										memcpy(cos_dat, &uart_rbuf[PACK_DATA], cos_len);
										sta = PCD_mfpro_comm(cos_cidnad, cos_fwi, &cos_len, cos_dat);
										
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
													uart_rbuf[PACK_COMM], sta, cos_len, cos_dat, uart_sbuf);
				        } 
								else 
								{	// ????????
										PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
										uart_rbuf[PACK_COMM], 0x11, 0, 0, uart_sbuf);
				        }
			    } 
					else 
					{
				      PDA_package(uart_rbuf[PACK_NUMB], uart_rbuf[PACK_COMT],
					    uart_rbuf[PACK_COMM], 0x10, 0, 0, uart_sbuf);
			    }
						
					if(CARD_OPER == Card_Null) //???????,????
					{
             uart_putd(uart_sbuf);                          
			       for (i=0; i<16; i++) 
						      dat_buf[i] = 0x00;                                            
             uart_clr();       
          }
					recv_flag = 0;
					uart_indx = 0;             
		   }
		}
}



unsigned short crc16_tab[256] = {
	0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
	0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
	0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
	0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
	0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
	0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
	0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
	0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
	0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
	0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
	0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
	0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
	0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
	0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
	0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
	0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
	0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
	0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
	0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
	0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
	0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
	0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
	0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
	0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
	0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
	0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
	0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
	0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
	0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
	0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
	0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
	0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
};


unsigned short crc16_table(unsigned char *pcrc, unsigned short cnt)
{
	unsigned short crc16 = 0;
	unsigned char crc_reg;
	for ( ; cnt>0; cnt--) 
	{
		crc_reg = (unsigned char) (crc16>>8);
		crc16 <<= 8;
		crc16 ^= crc16_tab[crc_reg ^ *pcrc];
		pcrc++;
	}
	
	return crc16;
}


void PDA_package(unsigned char num, unsigned char com_type,
		 unsigned char com, unsigned char ack,
		 unsigned char len, unsigned char *dat, unsigned char *buf)
{
	unsigned int crc;

	buf[PACK_HEAD] = PDA_HEAD;
	buf[PACK_LENG] = len + 7;
	buf[PACK_NUMB]  = num;
	buf[PACK_COMT] = com_type;
	buf[PACK_COMM] = com;
	buf[PACK_ACKN]  = ack;
	buf[PACK_DALE] = len;
	
	if (len != 0)
		memcpy(&buf[7], dat, len);
	
	crc = crc16_table(buf, buf[PACK_LENG]);
	buf[buf[PACK_LENG]]   = crc>>8 & 0xFF;
	buf[buf[PACK_LENG]+1] = crc & 0xFF;
}



void uart_clr(void)
{
	unsigned char i;
	for (i=0; i<50; i++) {
		uart_rbuf[i] = 0x00;
		uart_sbuf[i] = 0x00;
	}
}


void uart_putc(unsigned char byte)
{
  	while (!(USART1->SR & USART_FLAG_TXE));
   	USART1->DR = (byte & (uint16_t)0x01FF);	   
}


void uart_puts(unsigned char *s)
{
	unsigned int i = 0;
	for (i=0; s[i] != '\0'; i++) {
		uart_putc(s[i]);
	}
}


void uart_putd(unsigned char *d)
{
	unsigned int i = 0;
	unsigned int l = d[PACK_LENG]+2;
	for (i=0; i < l; i++) {
		uart_putc(d[i]);
		//delay_50us(1);
	}
}


