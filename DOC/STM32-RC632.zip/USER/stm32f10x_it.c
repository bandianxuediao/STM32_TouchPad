/**
  ******************************************************************************
  * @file    GPIO/IOToggle/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h" 
#include "bsp_usart.h"
#include <stdio.h>


 
void NMI_Handler(void)
{
}
 
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}
 
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

 
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}
 
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}
 
void SVC_Handler(void)
{
}
 
void DebugMon_Handler(void)
{
}
 
void PendSV_Handler(void)
{
}
 
void SysTick_Handler(void)
{
}



/****************************************************************************
* ��    �ƣ�void EXTI2_IRQHandler(void)
* ��    �ܣ��ȴ�ʱ��
* ��ڲ�������
* ���ڲ�������
* ˵    ����
* ���÷������� 
****************************************************************************/ 
void EXTI2_IRQHandler(void)
{
	if (EXTI_GetITStatus(EXTI_Line2) != RESET) 
	{
	  	EXTI_ClearITPendingBit(EXTI_Line2);		  
		  printf("����ģ���ж�\r\n");
	}
}

#define PDA_HEAD	    0xA5
#define PDA_COMT_SET	0x57
#define PDA_COMT_REQ	0x52
#define PDA_COMT_AUTO	0x41

#define PACK_HEAD	0
#define PACK_LENG	1
#define PACK_NUMB	2
#define PACK_COMT	3
#define PACK_COMM	4
#define PACK_ACKN	5
#define PACK_DALE	6
#define PACK_DATA	7

extern unsigned char uart_indx, recv_flag;
extern unsigned char uart_sbuf[50];
extern unsigned char uart_rbuf[50];
//����GPSģ����Ϣ
void USART1_IRQHandler(void)
{
	u8 ReciveData = 0;	    
  if(USART1->SR&(1<<5))	  //�жϷ��������ж�
	{		  
      ReciveData = USART1->DR;   //�����Ĵ��������ݻ��浽���ջ�������
    	uart_rbuf[uart_indx] = ReciveData;
			USART1->SR &= ~(1<<5);          //����жϱ�־	
      if (uart_rbuf[0] != PDA_HEAD)
			{
					uart_indx = 0;
			} 
			else 
			{
				if ((uart_indx >= 1) && (uart_rbuf[PACK_LENG] == (uart_indx-1))) 
				{
					recv_flag = 1;
					uart_indx = 0;
				} 
				else 
				{
					uart_indx++;
				}
			}
  }
	
	
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/
