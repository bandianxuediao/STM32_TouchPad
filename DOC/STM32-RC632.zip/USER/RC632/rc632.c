#include "rc632.h"
#include "spi_rc632.h"
#include "bsp_delay.h"
#include <string.h>




void rc_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
  
	RCC_APB2PeriphClockCmd(	RCC_APB2Periph_GPIOA, ENABLE );	
 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  //¸´ÓÃÍÆÍìÊä³ö
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;  //¸´ÓÃÍÆÍìÊä³ö
 	GPIO_SetBits(GPIOA,GPIO_Pin_2);	
	
	SPIx_Init();
	
}


unsigned char rc_read_raw(unsigned char addr)
{
	unsigned char result = 0;
	
	RCPIN_CS_LOW;
	addr = ((addr<<1) & 0x7E) | 0x80;
	
  SPIx_ReadWriteByte(addr);
	
	result = SPIx_ReadWriteByte(0x00);
	
	RCPIN_CS_HIGH;

	return result;
}


void rc_write_raw(unsigned char addr, unsigned char val)
{
	RCPIN_CS_LOW;
	
	addr = ((addr<<1) & 0x7E);
	
	SPIx_ReadWriteByte(addr);
	SPIx_ReadWriteByte(val);
	
	RCPIN_CS_HIGH;
}




void set_bit_mask(unsigned char reg, unsigned char mask)
{
	char tmp = 0x00;
	tmp = rc_read_raw(reg);
	rc_write_raw(reg, tmp | mask);
}


void clr_bit_mask(unsigned char reg, unsigned char mask)
{
	char tmp = 0x00;
	tmp = rc_read_raw(reg);
	rc_write_raw(reg, tmp & ~mask);
}


signed char PCD_reset(void)
{
	signed char sta = MI_OK;
	char n = 0xFF;
	unsigned int i = 3000;
	
	RCPIN_CS_LOW;
	RCPIN_RST_LOW;
	delay_ms(50);
	
	RCPIN_RST_HIGH;
	delay_ms(5);
	
	RCPIN_RST_LOW;
	RCPIN_CS_LOW;
	delay_ms(5);
	
	while (i!=0 && n) {
		n = rc_read_raw(REG_COMM);
		i--;
	}
	
	if (i != 0) {
		rc_write_raw(REG_PAGE, 0x80);
		n = 0x80;
		while ((i!=0) && (n&0x80)) {
			n = rc_read_raw(REG_COMM);
			i--;
		}
		
		if (i==0 || (n&0xFF))
			sta = (signed char)MI_RESET_ERR;
	} else {
		sta = (signed char)MI_RESET_ERR;
	}
	
	if (sta == MI_OK)
		rc_write_raw(REG_PAGE, 0x00);
	return sta;
}


signed char PCD_AntennaON(void)
{
	unsigned char i;
	i = rc_read_raw(REG_TX_CTRL);
	if (i & 0x03) 
	{
		return MI_OK;
	} 
	else 
	{
		set_bit_mask(REG_TX_CTRL, 0x03);
		return MI_OK;
	}
}


signed char PCD_AntennaOFF(void)
{
	clr_bit_mask(REG_TX_CTRL, 0x03);
	return MI_OK;
}


void mode_14443A(void)
{
	clr_bit_mask(REG_CTRL, 0x08);
	
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x00);
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x40);
	delay_us(2);
	clr_bit_mask(REG_CLOCK_Q_CTRL, 0x40);
	
	rc_write_raw(REG_TX_CTRL, 0x5B);
	rc_write_raw(REG_CW_CONDUCTANCE, 0x0F);
	rc_write_raw(REG_MOD_CONDUCTANCE, 0x3F);
	rc_write_raw(REG_CODER_CTRL, 0x19);  //MIFARE 106 kBd; ISO/IEC 14443 A  MIFARE, ISO/IEC 14443 A, (Miller coded)
	//rc_write_raw(REG_CODER_CTRL, 0x11);  
        
        rc_write_raw(REG_MOD_WIDTH, 0x13);
	rc_write_raw(REG_MOD_WIDTH_SOF, 0x00);
	rc_write_raw(REG_TYPEB_FRAMING, 0x00);
	
	rc_write_raw(REG_RX_CTRL1, 0x73);
	rc_write_raw(REG_DECODER_CTRL, 0x08);
	rc_write_raw(REG_BIT_PHASE, 0xAD);
	rc_write_raw(REG_RX_THRESHOLD, 0xAA);
	rc_write_raw(REG_BPSK_DEM_CTRL, 0x00);
	rc_write_raw(REG_RX_CTRL2, 0x41);
	
	rc_write_raw(REG_RX_WAIT, 0x06);
	rc_write_raw(REG_CH_REDUNDANCY, 0x0F);
	rc_write_raw(REG_CRC_PRESET_LSB, 0x63);
	rc_write_raw(REG_CRC_PRESET_MSB, 0x63);
	rc_write_raw(REG_TIME_SOLT_PERIOD, 0x00);
	rc_write_raw(REG_MFOUT_SELECT, 0x00);
	rc_write_raw(REG_PRESET_27, 0x00);
	
	rc_write_raw(REG_FIFO_LEVEL, 0x3F);
	rc_write_raw(REG_TIMER_CLOCK, 0x07);
	rc_write_raw(REG_TIMER_RELOAD, 0x0A);
	rc_write_raw(REG_TIMER_CTRL, 0x06);
	rc_write_raw(REG_IRQ_PIN_CFG, 0x02);
	rc_write_raw(REG_PRESET_2E, 0x00);
	rc_write_raw(REG_PRESET_2F, 0x00);
	
	PCD_set_TMO(106);
	delay_ms(1);
	PCD_AntennaON();
}


void mode_14443B(void)
{
	clr_bit_mask(REG_CTRL, 0x08);
	
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x00);
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x40);
	delay_us(2);
	clr_bit_mask(REG_CLOCK_Q_CTRL, 0x40);
	
	rc_write_raw(REG_TX_CTRL, 0x4B);
	rc_write_raw(REG_CW_CONDUCTANCE, 0x17);
	rc_write_raw(REG_MOD_CONDUCTANCE, 0x06);
	rc_write_raw(REG_CODER_CTRL, 0x20);
	rc_write_raw(REG_MOD_WIDTH, 0x13);
	rc_write_raw(REG_MOD_WIDTH_SOF, 0x3F);
	rc_write_raw(REG_TYPEB_FRAMING, 0x3B);
	
	rc_write_raw(REG_RX_CTRL1, 0x73);
	rc_write_raw(REG_DECODER_CTRL, 0x19);
	rc_write_raw(REG_BIT_PHASE, 0xAD);
	rc_write_raw(REG_RX_THRESHOLD, 0x88);
	rc_write_raw(REG_BPSK_DEM_CTRL, 0x7E);
	rc_write_raw(REG_RX_CTRL2, 0x01);
	
	rc_write_raw(REG_RX_WAIT, 0x06);
	rc_write_raw(REG_CH_REDUNDANCY, 0x2C);
	rc_write_raw(REG_CRC_PRESET_LSB, 0xFF);
	rc_write_raw(REG_CRC_PRESET_MSB, 0xFF);
	rc_write_raw(REG_TIME_SOLT_PERIOD, 0x00);
	rc_write_raw(REG_MFOUT_SELECT, 0x00);
	rc_write_raw(REG_PRESET_27, 0x00);
	
	rc_write_raw(REG_FIFO_LEVEL, 0x3F);
	rc_write_raw(REG_TIMER_CLOCK, 0x07);
	rc_write_raw(REG_TIMER_RELOAD, 0x0A);
	rc_write_raw(REG_TIMER_CTRL, 0x06);
	rc_write_raw(REG_IRQ_PIN_CFG, 0x02);
	rc_write_raw(REG_PRESET_2E, 0x00);
	rc_write_raw(REG_PRESET_2F, 0x00);
	
	PCD_set_TMO(106);
	delay_ms(1);
	PCD_AntennaON();
}


void mode_r(void)
{
	clr_bit_mask(REG_CTRL, 0x08);
	
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x00);
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x40);
	delay_us(2);
	clr_bit_mask(REG_CLOCK_Q_CTRL, 0x40);
	
	rc_write_raw(REG_TX_CTRL, 0x4B);
	rc_write_raw(REG_CW_CONDUCTANCE, 0x06);
	rc_write_raw(REG_MOD_CONDUCTANCE, 0x03);
	rc_write_raw(REG_CODER_CTRL, 0x20);
	rc_write_raw(REG_MOD_WIDTH, 0x13);
	rc_write_raw(REG_MOD_WIDTH_SOF, 0x00);
	rc_write_raw(REG_TYPEB_FRAMING, 0x3B);
	
	rc_write_raw(REG_RX_CTRL1, 0x73);
	rc_write_raw(REG_DECODER_CTRL, 0x19);
	rc_write_raw(REG_BIT_PHASE, 0xAD);
	rc_write_raw(REG_RX_THRESHOLD, 0x88);
	rc_write_raw(REG_BPSK_DEM_CTRL, 0x3E);
	rc_write_raw(REG_RX_CTRL2, 0x01);
	
	rc_write_raw(REG_RX_WAIT, 0x06);
	rc_write_raw(REG_CH_REDUNDANCY, 0x2C);
	rc_write_raw(REG_CRC_PRESET_LSB, 0xFF);
	rc_write_raw(REG_CRC_PRESET_MSB, 0xFF);
	rc_write_raw(REG_TIME_SOLT_PERIOD, 0x00);
	rc_write_raw(REG_MFOUT_SELECT, 0x00);
	rc_write_raw(REG_PRESET_27, 0x00);
	
	rc_write_raw(REG_FIFO_LEVEL, 0x1A);
	rc_write_raw(REG_TIMER_CLOCK, 0x07);
	rc_write_raw(REG_TIMER_RELOAD, 0x0A);
	rc_write_raw(REG_TIMER_CTRL, 0x06);
	rc_write_raw(REG_IRQ_PIN_CFG, 0x02);
	rc_write_raw(REG_PRESET_2E, 0x00);
	rc_write_raw(REG_PRESET_2F, 0x00);
	
	PCD_set_TMO(106);
	delay_ms(1);
	PCD_AntennaON();
}


void mode_s(void)
{
	clr_bit_mask(REG_CTRL, 0x08);
	
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x00);
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x40);
	delay_us(2);
	clr_bit_mask(REG_CLOCK_Q_CTRL, 0x40);
	
	rc_write_raw(REG_TX_CTRL, 0x4B);
	rc_write_raw(REG_CW_CONDUCTANCE, 0x06);
	rc_write_raw(REG_MOD_CONDUCTANCE, 0x03);
	rc_write_raw(REG_CODER_CTRL, 0x20);
	rc_write_raw(REG_MOD_WIDTH, 0x13);
	rc_write_raw(REG_MOD_WIDTH_SOF, 0x00);
	rc_write_raw(REG_TYPEB_FRAMING, 0x18);
	
	rc_write_raw(REG_RX_CTRL1, 0x73);
	rc_write_raw(REG_DECODER_CTRL, 0x19);
	rc_write_raw(REG_BIT_PHASE, 0xAD);
	rc_write_raw(REG_RX_THRESHOLD, 0x88);
	rc_write_raw(REG_BPSK_DEM_CTRL, 0x3E);
	rc_write_raw(REG_RX_CTRL2, 0x01);
	
	rc_write_raw(REG_RX_WAIT, 0x06);
	rc_write_raw(REG_CH_REDUNDANCY, 0x2C);
	rc_write_raw(REG_CRC_PRESET_LSB, 0xFF);
	rc_write_raw(REG_CRC_PRESET_MSB, 0xFF);
	rc_write_raw(REG_TIME_SOLT_PERIOD, 0x00);
	rc_write_raw(REG_MFOUT_SELECT, 0x00);
	rc_write_raw(REG_PRESET_27, 0x00);
	
	rc_write_raw(REG_FIFO_LEVEL, 0x3F);
	rc_write_raw(REG_TIMER_CLOCK, 0x07);
	rc_write_raw(REG_TIMER_RELOAD, 0x0A);
	rc_write_raw(REG_TIMER_CTRL, 0x06);
	rc_write_raw(REG_IRQ_PIN_CFG, 0x02);
	rc_write_raw(REG_PRESET_2E, 0x00);
	rc_write_raw(REG_PRESET_2F, 0x00);
	
	PCD_set_TMO(106);
	delay_ms(1);
	PCD_AntennaON();
}


void mode_15693(void)
{
	clr_bit_mask(REG_CTRL, 0x08);
	
	rc_write_raw(REG_TX_CTRL, 0x48);
	rc_write_raw(REG_CW_CONDUCTANCE, 0x3F);
	rc_write_raw(REG_MOD_CONDUCTANCE, 0x05);
	rc_write_raw(REG_CODER_CTRL, 0x2F);
	rc_write_raw(REG_MOD_WIDTH, 0x3F);
	rc_write_raw(REG_MOD_WIDTH_SOF, 0x3F);
	rc_write_raw(REG_TYPEB_FRAMING, 0x00);
	
	rc_write_raw(REG_RX_CTRL1, 0x8B);
	rc_write_raw(REG_DECODER_CTRL, 0x34);
	rc_write_raw(REG_BIT_PHASE, 0xCD);
	rc_write_raw(REG_RX_THRESHOLD, 0x88);
	rc_write_raw(REG_BPSK_DEM_CTRL, 0x00);
	rc_write_raw(REG_RX_CTRL2, 0x01);
	rc_write_raw(REG_CLOCK_Q_CTRL, 0x00);
	
	rc_write_raw(REG_RX_WAIT, 0x08);
	rc_write_raw(REG_CH_REDUNDANCY, 0x2C);
	rc_write_raw(REG_CRC_PRESET_LSB, 0xFF);
	rc_write_raw(REG_CRC_PRESET_MSB, 0xFF);
	rc_write_raw(REG_TIME_SOLT_PERIOD, 0x00);
	rc_write_raw(REG_MFOUT_SELECT, 0x00);
	rc_write_raw(REG_PRESET_27, 0x00);
	
	rc_write_raw(REG_FIFO_LEVEL, 0x38);
	rc_write_raw(REG_TIMER_CLOCK, 0x0B);
	rc_write_raw(REG_TIMER_RELOAD, 0x00);
	rc_write_raw(REG_TIMER_CTRL, 0x02);
	rc_write_raw(REG_PRESET_2E, 0x00);
	rc_write_raw(REG_PRESET_2F, 0x00);
	
	delay_ms(1);
	PCD_AntennaON();
}

signed char PCD_cfg_iso_type(unsigned char type)
{
	if (type == 'A') {
		mode_14443A();
	} else if (type == 'B') {
		mode_14443B();
	} else if (type == 'r') {
		mode_r();
	} else if (type == 's') {
		mode_s();
	} else if (type == '1') {
		mode_15693();
	} else {
		return -1;
	}
	
	return MI_OK;
}


void PCD_set_TMO(unsigned char tmo_leng)
{
	switch (tmo_leng) {
	case 0:
		rc_write_raw(REG_TIMER_CLOCK, 0x07);
		rc_write_raw(REG_TIMER_RELOAD, 0x21);
		break;
	case 1:
		rc_write_raw(REG_TIMER_CLOCK, 0x07);
		rc_write_raw(REG_TIMER_RELOAD, 0x41);
		break;
	case 2:
		rc_write_raw(REG_TIMER_CLOCK, 0x07);
		rc_write_raw(REG_TIMER_RELOAD, 0x81);
		break;
	case 3:
		rc_write_raw(REG_TIMER_CLOCK, 0x09);
		rc_write_raw(REG_TIMER_RELOAD, 0x41);
		break;
	case 4:
		rc_write_raw(REG_TIMER_CLOCK, 0x09);
		rc_write_raw(REG_TIMER_RELOAD, 0x81);
		break;
	case 5:
		rc_write_raw(REG_TIMER_CLOCK, 0x0B);
		rc_write_raw(REG_TIMER_RELOAD, 0x41);
		break;
	case 6:
		rc_write_raw(REG_TIMER_CLOCK, 0x0B);
		rc_write_raw(REG_TIMER_RELOAD, 0x81);
		break;
	case 7:
		rc_write_raw(REG_TIMER_CLOCK, 0x0D);
		rc_write_raw(REG_TIMER_RELOAD, 0x41);
		break;
	case 8:
		rc_write_raw(REG_TIMER_CLOCK, 0x0D);
		rc_write_raw(REG_TIMER_RELOAD, 0x81);
		break;
	case 9:
		rc_write_raw(REG_TIMER_CLOCK, 0x0F);
		rc_write_raw(REG_TIMER_RELOAD, 0x41);
		break;
	case 10:
		rc_write_raw(REG_TIMER_CLOCK, 0x0F);
		rc_write_raw(REG_TIMER_RELOAD, 0x81);
		break;
	case 11:
		rc_write_raw(REG_TIMER_CLOCK, 0x13);
		rc_write_raw(REG_TIMER_RELOAD, 0x11);
		break;
	case 12:
		rc_write_raw(REG_TIMER_CLOCK, 0x13);
		rc_write_raw(REG_TIMER_RELOAD, 0x21);
		break;
	case 13:
		rc_write_raw(REG_TIMER_CLOCK, 0x13);
		rc_write_raw(REG_TIMER_RELOAD, 0x41);
		break;
	case 14:
		rc_write_raw(REG_TIMER_CLOCK, 0x13);
		rc_write_raw(REG_TIMER_RELOAD, 0x81);
		break;
	case 15:
		rc_write_raw(REG_TIMER_CLOCK, 0x09);
		rc_write_raw(REG_TIMER_RELOAD, 0xFF);
		break;
	default:
		rc_write_raw(REG_TIMER_CLOCK, 0x19);
		rc_write_raw(REG_TIMER_RELOAD, tmo_leng);
		break;
	}
	
	rc_write_raw(REG_TIMER_CTRL, 0x06);
}

//密钥算法。。
void getCardKey(unsigned char cardSn[4], unsigned char keyFactor[6], unsigned char key[6])
{
	unsigned char a[4];
  unsigned char Nkey_a[6];
	
	a[0] = cardSn[0]; //04
	a[1] = cardSn[1]; //8D
	a[2] = cardSn[2]; //94
	a[3] = cardSn[3]; //43

  //79 D6 54 70 CD E7 
	Nkey_a[0] = a[0] + a[1] + a[2] + a[3] + keyFactor[0];
	Nkey_a[1] = a[0] ^ a[1] ^ a[2] ^ a[3] ^ keyFactor[1];
	Nkey_a[2] = (unsigned char)(a[0] + a[1]) ^ a[2] ^ a[3] ^ keyFactor[2];
	Nkey_a[3] = (unsigned char)(a[0] + a[1] + a[2]) ^ a[3] ^ keyFactor[3];
	Nkey_a[4] = (unsigned char)(a[0] ^ a[1]) + a[2] + a[3] + keyFactor[4];
	Nkey_a[5] = (unsigned char)(a[0] ^ a[1] ^ a[2] + a[3]) + keyFactor[5];

	memcpy(key, Nkey_a, 6);
}

