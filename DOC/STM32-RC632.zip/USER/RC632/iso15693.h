#ifndef __SKY_PDA_ISO15693_H__
#define __SKY_PDA_ISO15693_H__

#define	ISO15693_INVENTORY			0x01
#define	ISO15693_STAY_QUIET			0x02
#define	ISO15693_READ_SINGLE_BLOCK		0x20
#define	ISO15693_WRITE_SINGLE_BLOCK		0x21
#define	ISO15693_LOCK_BLOCK			0x22
#define	ISO15693_READ_MULTIPLE_BLOCKS		0x23
#define	ISO15693_WRITE_MULTIPLE_BLOCKS		0x24
#define	ISO15693_SELECT				0x25
#define	ISO15693_RESET_TO_READY			0x26
#define	ISO15693_WRITE_AFI			0x27
#define	ISO15693_LOCK_AFI			0x28
#define	ISO15693_WRITE_DSFID			0x29
#define	ISO15693_LOCK_DSFID			0x2A
#define	ISO15693_GET_SYSTEM_INFO		0x2B
#define	ISO15693_GET_MULT_BLOCK_SECURITY	0x2C

//char PCD_15693_trans(struct trans_buff *pi);
signed char ISO15693_inventory(unsigned char flags, unsigned char AFI,
			unsigned char mask_l, unsigned char *uid,
			unsigned char *resp);
signed char ISO15693_inventory16(unsigned char flags, unsigned char AFI,
			  unsigned char mask_l, unsigned char *uid,
			  unsigned char *resplen, unsigned char *resp);
signed char ISO15693_stay_quiet(unsigned char flags, unsigned char *uid);
signed char ISO15693_select(unsigned char flags, unsigned char *uid);
signed char ISO15693_reset_to_ready(unsigned char flags, unsigned char *uid);
signed char ISO15693_read_sm(unsigned char flags, unsigned char *uid,
		      unsigned char blnr, unsigned char nbl,
		      unsigned char *resplen, unsigned char *resp);
signed char ISO15693_write_sm(unsigned char flags, unsigned char *uid,
		       unsigned char blnr, unsigned char *dat);
signed char ISO15693_lock_block(unsigned char flags, unsigned char *uid,
			 unsigned char blnr);
signed char ISO15693_write_AFI(unsigned char flags, unsigned char *uid, unsigned char AFI);
signed char ISO15693_lock_AFI(unsigned char flags, unsigned char *uid);

unsigned char PDA_15693_snr(unsigned char *snr);

#endif

