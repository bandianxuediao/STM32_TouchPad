#include "rc632.h"
#include "iso15693.h"
#include "bsp_delay.h"

struct trans_buff {
	signed char   mf_comm;
	unsigned int  mf_leng;
	unsigned char mf_data[64];
};


signed char PCD_15693_trans(struct trans_buff *pi)
{
	signed char recebyte = 0;
	signed char sta = MI_COMM_ERR;
	unsigned char n, wait_for, timer_reload;
	unsigned int i;
	
	switch (pi->mf_comm) {
	case PCD_TRANSMIT:
		wait_for = 0x10;
		break;
	default:
		wait_for = 0x28;
		recebyte = 1;
		break;
	}
	
	switch (pi->mf_data[1]) {
	case ISO15693_STAY_QUIET:
		timer_reload = 0x04;
		break;
	case ISO15693_SELECT:
	case ISO15693_RESET_TO_READY:
		timer_reload = 0x0F;
		break;
	case ISO15693_LOCK_AFI:
	case ISO15693_LOCK_DSFID:
	case ISO15693_LOCK_BLOCK:
	case ISO15693_WRITE_SINGLE_BLOCK:
	case ISO15693_WRITE_MULTIPLE_BLOCKS:
	case ISO15693_WRITE_AFI:
	case ISO15693_WRITE_DSFID:
		timer_reload = 0x29;
		break;
	case ISO15693_READ_SINGLE_BLOCK:
		timer_reload = 0x17;
		break;
	case ISO15693_INVENTORY:
		timer_reload = 0x1F;
		break;
	case ISO15693_GET_SYSTEM_INFO:
		timer_reload = 0x25;
		break;
	case ISO15693_GET_MULT_BLOCK_SECURITY:
		timer_reload = 0x40;
		break;
	case ISO15693_READ_MULTIPLE_BLOCKS:
		timer_reload = 0x40;
		break;
	default:
		timer_reload = 0x86;
		break;
	}
	
	rc_write_raw(REG_PAGE, 0x00);
	rc_write_raw(REG_FIFO_LEVEL, 0x1A);
	
	set_bit_mask(REG_CH_REDUNDANCY, 0x04);
	rc_write_raw(REG_TIMER_RELOAD, timer_reload);
	rc_write_raw(REG_TIMER_CTRL, 0x06);
	
	set_bit_mask(REG_CTRL, 0x01);
	rc_write_raw(REG_COMM, 0x00);
	rc_write_raw(REG_IRQ_EN, 0x81);
	rc_write_raw(REG_IRQ_REQ, 0x3F);
	rc_write_raw(REG_IRQ_EN, 0x38|0x80);
	
	for (i=0; i<(pi->mf_leng); i++)
		rc_write_raw(REG_FIFO_DATA, pi->mf_data[i]);
	rc_write_raw(REG_COMM, PCD_TRANSCEIVE);
	
	i = 0x3000;
	do {
		n = rc_read_raw(REG_IRQ_REQ);
		i--;
	} while ((i!=0) && !(n & wait_for));
	
	if (!recebyte) {
		if (n & 0x10)
			sta = MI_OK;
		rc_write_raw(REG_IRQ_EN, 0x10);
		rc_write_raw(REG_TIMER_CTRL, 0x00);
		rc_write_raw(REG_COMM, PCD_IDLE);
		clr_bit_mask(REG_CODER_CTRL, 0x80);
		return sta;
	} else {
		if ((i!=0) && (n & 0x08)) {
			if (!(rc_read_raw(REG_ERR_FLAG) & 0x0C)) {
				n = rc_read_raw(REG_FIFO_LENG);
				pi->mf_leng = n*8;
				for (i=0; i<n; i++)
					pi->mf_data[i] = rc_read_raw(REG_FIFO_DATA);
				if (pi->mf_data[0] == 0)
					sta = MI_OK;
			}
		}
		
		rc_write_raw(REG_IRQ_EN, 0x10);
		rc_write_raw(REG_TIMER_CTRL, 0x00);
		rc_write_raw(REG_COMM, PCD_IDLE);
		clr_bit_mask(REG_CODER_CTRL, 0x80);
		return sta;
	}
}


signed char ISO15693_inventory(unsigned char flags, unsigned char AFI,
			unsigned char mask_l, unsigned char *uid,
			unsigned char *resp)
{
	signed char snd_cnt, cnt, sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_INVENTORY;
	snd_cnt = 2;
	if (flags & 0x10) {
		comm_data.mf_data[snd_cnt] = AFI;
		snd_cnt++;
	}
	comm_data.mf_data[snd_cnt] = mask_l;
	snd_cnt++;
	if (mask_l % 8)
		cnt = mask_l/8+1;
	else
		cnt = mask_l/8;
	
	if (cnt)
		memcpy(&comm_data.mf_data[snd_cnt], uid, cnt);
	comm_data.mf_leng = cnt + snd_cnt;
	sta = PCD_15693_trans(pi);
	if (sta == MI_OK) {
		if (comm_data.mf_leng != 0x50)
			sta = MI_BIT_COUNT_ERR;
		else
			memcpy(resp, &comm_data.mf_data[1], 9);
	}
	
	return sta;
}


signed char ISO15693_inventory16(unsigned char flags, unsigned char AFI,
			  unsigned char mask_l, unsigned char *uid,
			  unsigned char *resplen, unsigned char *resp)
{
	signed char snd_cnt, cnt, sta, i, j;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	sta = MI_COMM_ERR;
	*resplen = 0;
	set_bit_mask(REG_CH_REDUNDANCY, 0x04);
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	
	comm_data.mf_comm = PCD_TRANSMIT;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_INVENTORY;
	snd_cnt = 2;
	if (flags & 0x10) {
		comm_data.mf_data[snd_cnt] = AFI;
		snd_cnt++;
	}
	
	comm_data.mf_data[snd_cnt] = mask_l;
	snd_cnt++;
	if (mask_l % 8)
		cnt = mask_l/8 + 1;
	else
		cnt = mask_l/8;
	
	if (cnt)
		memcpy(&comm_data.mf_data[snd_cnt], uid, cnt);
	comm_data.mf_leng = cnt + snd_cnt;
	sta = PCD_15693_trans(pi);

	j=0;
	for (i=0; i<16; i++) {
		pi = &comm_data;
		clr_bit_mask(REG_CH_REDUNDANCY, 0x04);
		set_bit_mask(REG_CODER_CTRL, 0x80);
		set_bit_mask(REG_TX_CTRL, 0x10);
		comm_data.mf_comm = PCD_TRANSCEIVE;
		comm_data.mf_leng = 0;
		
		sta = PCD_15693_trans(pi);
		if ((sta == MI_OK) && (comm_data.mf_leng == 0x50)) {
			sta = MI_OK;
			*resplen += 9;
			memcpy(resp+9*j, &comm_data.mf_data[1], 9);
			j++;
		}
		
		if (*resplen >= 36) break;
	}
	
	return sta;
}


signed char ISO15693_stay_quiet(unsigned char flags, unsigned char *uid)
{
	signed char sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	comm_data.mf_comm = PCD_TRANSMIT;
	comm_data.mf_leng = 10;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_STAY_QUIET;
	memcpy(&comm_data.mf_data[2], uid, 8);
	
	sta = PCD_15693_trans(pi);
	return sta;
}


signed char ISO15693_select(unsigned char flags, unsigned char *uid)
{
	signed char sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_leng = 10;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_SELECT;
	memcpy(&comm_data.mf_data[2], uid, 8);
	
	sta = PCD_15693_trans(pi);
	if ((sta == MI_OK) && (comm_data.mf_leng != 0x08))
		sta = MI_BIT_COUNT_ERR;
	return sta;
}


signed char ISO15693_reset_to_ready(unsigned char flags, unsigned char *uid)
{
	signed char cnt, sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_RESET_TO_READY;
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&comm_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	
	comm_data.mf_leng = cnt;
	sta = PCD_15693_trans(pi);
	if ((sta == MI_OK) && (comm_data.mf_leng != 0x08))
		sta = MI_BIT_COUNT_ERR;
	return sta;
}


// single/multiple block
signed char ISO15693_read_sm(unsigned char flags, unsigned char *uid,
		      unsigned char blnr, unsigned char nbl,
		      unsigned char *resplen, unsigned char *resp)
{
	unsigned char cnt;
  signed char	sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	*resplen = 0;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (nbl) nbl--;
	comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_data[0] = flags;
	if (nbl)
		comm_data.mf_data[1] = ISO15693_READ_MULTIPLE_BLOCKS;
	else
		comm_data.mf_data[1] = ISO15693_READ_SINGLE_BLOCK;
	cnt = 2;
	if ((flags & 0x20) && !(flags & 0x10)) {
		memcpy(&comm_data.mf_data[cnt], uid, 8);
		cnt = cnt + 8;
	}
	comm_data.mf_data[cnt] = blnr;
	if (nbl) {
		cnt++;
		comm_data.mf_data[cnt] = nbl;
	}
	
	comm_data.mf_leng = cnt + 1;
	sta = PCD_15693_trans(pi);
	if (sta == MI_OK) {
		*resplen = comm_data.mf_leng/8 - 1;
		memcpy(resp, &comm_data.mf_data[1], *resplen);
	}
	return sta;
}


// write single
signed char ISO15693_write_sm(unsigned char flags, unsigned char *uid,
		       unsigned char blnr, unsigned char *dat)
{
	signed char sta;
	unsigned char cnt;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (flags & 0x40)
		comm_data.mf_comm = PCD_TRANSMIT;
	else
		comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_WRITE_SINGLE_BLOCK;
	cnt = 2;
	
	if (flags & 0x20) {
		memcpy(&comm_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	comm_data.mf_data[cnt] = blnr;
	cnt++;
	
	memcpy(&comm_data.mf_data[cnt], dat, 4);
	cnt = cnt + 4;
	
	comm_data.mf_leng = cnt;
	sta = PCD_15693_trans(pi);
	if (sta != MI_OK) {
		return sta;
	} else if (!(flags & 0x40)) {
		if (comm_data.mf_leng != 0x08)
			sta = MI_BIT_COUNT_ERR;
		return sta;
	} else {
		delay_ms(10);
		pi = &comm_data;
		
		set_bit_mask(REG_CODER_CTRL, 0x80);
		comm_data.mf_comm = PCD_TRANSCEIVE;
		comm_data.mf_leng = 0;
		sta = PCD_15693_trans(pi);
		if ((sta == MI_OK) && (comm_data.mf_leng != 0x08))
			sta = MI_BIT_COUNT_ERR;
		return sta;
	}
}


signed char ISO15693_lock_block(unsigned char flags, unsigned char *uid,
			 unsigned char blnr)
{
	signed char cnt, sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (flags & 0x40)
		comm_data.mf_comm = PCD_TRANSMIT;
	else
		comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_LOCK_BLOCK;
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&comm_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	comm_data.mf_data[cnt] = blnr;
	comm_data.mf_leng = cnt + 1;
	sta = PCD_15693_trans(pi);
	if (sta != MI_OK) {
		return sta;
	} else if (!(flags & 0x40)) {
		if (comm_data.mf_leng != 0x08)
			sta = MI_BIT_COUNT_ERR;
		return sta;
	} else {
		delay_ms(10);
		pi = &comm_data;
		
		set_bit_mask(REG_CODER_CTRL, 0x80);
		comm_data.mf_comm = PCD_TRANSCEIVE;
		comm_data.mf_leng = 0;
		sta = PCD_15693_trans(pi);
		if ((sta == MI_OK) && (comm_data.mf_leng != 0x08))
			sta = MI_BIT_COUNT_ERR;
		return sta;
	}
}


signed char ISO15693_write_AFI(unsigned char flags, unsigned char *uid, unsigned char AFI)
{
	signed char cnt, sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (flags & 0x40)
		comm_data.mf_comm = PCD_TRANSMIT;
	else
		comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_WRITE_AFI;
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&comm_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	
	comm_data.mf_data[cnt] = AFI;
	comm_data.mf_leng = cnt + 1;
	sta = PCD_15693_trans(pi);
	if (sta != MI_OK) {
		return sta;
	} else if (!(flags & 0x40)) {
		if (comm_data.mf_leng != 0x08)
			sta = MI_BIT_COUNT_ERR;
		return sta;
	} else {
		delay_ms(10);
		pi = &comm_data;
		set_bit_mask(REG_CODER_CTRL, 0x80);
		comm_data.mf_comm = PCD_TRANSCEIVE;
		comm_data.mf_leng = 0;
		sta = PCD_15693_trans(pi);
		if ((sta == MI_OK) && (comm_data.mf_leng != 0x08))
			sta = MI_BIT_COUNT_ERR;
		return sta;
	}
}


signed char ISO15693_lock_AFI(unsigned char flags, unsigned char *uid)
{
	signed char cnt, sta;
	struct trans_buff comm_data;
	struct trans_buff *pi;
	pi = &comm_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (flags & 0x40)
		comm_data.mf_comm = PCD_TRANSMIT;
	else
		comm_data.mf_comm = PCD_TRANSCEIVE;
	comm_data.mf_data[0] = flags;
	comm_data.mf_data[1] = ISO15693_LOCK_AFI;
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&comm_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	comm_data.mf_leng = cnt;
	
	sta = PCD_15693_trans(pi);
	if (sta != MI_OK) {
		return sta;
	} else if (!(flags & 0x40)) {
		if (comm_data.mf_leng != 0x08)
			sta = MI_BIT_COUNT_ERR;
		return sta;
	} else {
		delay_ms(10);
		pi = &comm_data;
		
		set_bit_mask(REG_CODER_CTRL, 0x80);
		comm_data.mf_comm = PCD_TRANSCEIVE;
		comm_data.mf_leng = 0;
		sta = PCD_15693_trans(pi);
		if ((sta == MI_OK) && (comm_data.mf_leng != 0x08))
			sta = MI_BIT_COUNT_ERR;
		return sta;
	}
}


signed char ISO15693_write_DSFID(unsigned char flags, unsigned char *uid,
			  unsigned char DSFID)
{
	signed char cnt, sta;
	struct trans_buff com_data;
	struct trans_buff *pi;
	pi = &com_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (flags & 0x40)
		com_data.mf_comm = PCD_TRANSMIT;
	else
		com_data.mf_comm = PCD_TRANSCEIVE;
	
	com_data.mf_data[0] = flags;
	com_data.mf_data[1] = ISO15693_WRITE_DSFID;
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&com_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	com_data.mf_data[cnt] = DSFID;
	com_data.mf_leng = cnt + 1;
	
	sta = PCD_15693_trans(pi);	
	if (sta != MI_OK) {
		return sta;
	} else if (!(flags & 0x40)) {
		if (com_data.mf_leng != 0x08)
			sta = MI_BIT_COUNT_ERR;
		return sta;
	} else {
		delay_ms(10);
		pi = &com_data;
		set_bit_mask(REG_CODER_CTRL, 0x80);
		
		com_data.mf_comm = PCD_TRANSCEIVE;
		com_data.mf_leng = 0;
		sta = PCD_15693_trans(pi);
		if ((sta==MI_OK) && (com_data.mf_leng != 0x08))
			sta = MI_BIT_COUNT_ERR;
		return sta;
	}
}


signed char ISO15693_lock_DSFID(unsigned char flags, unsigned char *uid)
{
	signed char cnt, sta;
	struct trans_buff com_data;
	struct trans_buff *pi;
	pi = &com_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (flags & 0x40)
		com_data.mf_comm = PCD_TRANSMIT;
	else
		com_data.mf_comm = PCD_TRANSCEIVE;
	com_data.mf_data[0] = flags;
	com_data.mf_data[1] = ISO15693_LOCK_DSFID;
	
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&com_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	com_data.mf_leng = cnt;
	
	sta = PCD_15693_trans(pi);
	if (sta != MI_OK) {
		return sta;
	} else if (!(flags & 0x40)) {
		if (com_data.mf_leng != 0x08)
			sta = MI_BIT_COUNT_ERR;
		return sta;
	} else {
		delay_ms(10);
		pi = &com_data;
		
		set_bit_mask(REG_CODER_CTRL, 0x80);
		com_data.mf_comm = PCD_TRANSCEIVE;
		com_data.mf_leng = 0;
		sta = PCD_15693_trans(pi);
		if ((sta==MI_OK) && (com_data.mf_leng != 0x08))
			sta = MI_BIT_COUNT_ERR;
		return sta;
	}
}


char ISO15693_get_system_info(unsigned char flags, unsigned char *uid,
			      unsigned char *resplen, unsigned char *resp)
{
	unsigned char cnt, sta;
	struct trans_buff com_data;
	struct trans_buff *pi;
	pi = &com_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	com_data.mf_comm = PCD_TRANSCEIVE;
	com_data.mf_data[0] = flags;
	com_data.mf_data[1] = ISO15693_GET_SYSTEM_INFO;
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&com_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	com_data.mf_leng = cnt;
	
	sta = PCD_15693_trans(pi);
	if (sta == MI_OK) {
		*resplen = com_data.mf_leng/8 - 1;
		memcpy(resp, &com_data.mf_data[1], *resplen);
	}
	
	return sta;
}


char ISO15693_get_mul_block_security(unsigned char flags, unsigned char *uid,
				     unsigned char blnr, unsigned char nbl,
				     unsigned char *resplen, unsigned char *resp)
{
	unsigned char cnt, sta;
	struct trans_buff com_data;
	struct trans_buff *pi;
	pi = &com_data;
	
	clr_bit_mask(REG_CODER_CTRL, 0x80);
	if (nbl)
		nbl--;
	*resplen = 0;
	
	com_data.mf_comm = PCD_TRANSCEIVE;
	com_data.mf_data[0] = flags;
	com_data.mf_data[1] = ISO15693_GET_MULT_BLOCK_SECURITY;
	cnt = 2;
	if (flags & 0x20) {
		memcpy(&com_data.mf_data[2], uid, 8);
		cnt = cnt + 8;
	}
	com_data.mf_data[cnt] = blnr;
	cnt++;
	com_data.mf_data[cnt] = nbl;
	com_data.mf_leng = cnt + 1;
	
	sta = PCD_15693_trans(pi);
	if (sta == MI_OK) {
		*resplen = com_data.mf_leng/8 - 1;
		memcpy(resp, &com_data.mf_data[1], *resplen);
	}
	
	return sta;
}


unsigned char PDA_15693_snr(unsigned char *snr)
{
	unsigned char buf[12];
	char sta;
	PCD_AntennaOFF();
	delay_ms(10);
	PCD_cfg_iso_type('1');
	delay_ms(10);

	if ((sta=ISO15693_inventory16(0x16, 0x00, 0x00, &buf[0], &buf[0], &buf[1]))
		== MI_OK) {
		memcpy(snr, &buf[2], 8);
	} else if ((sta=ISO15693_inventory(0x36, 0x00, 0x00, &buf[0], &buf[0]))
		== MI_OK) {
		memcpy(snr, &buf[1], 8);
	}

	PCD_AntennaOFF();
	return sta;
}
