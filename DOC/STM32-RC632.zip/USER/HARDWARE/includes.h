#ifndef __includes_H
#define __includes_H


#include <string.h>
#include <stdio.h>	 
#include "stm32f10x.h"
#include "bsp_delay.h"
#include "bsp_sys.h"
#include "bsp_usart.h"
#include "bsp_isrconfig.h"
#include "hardware_init.h"
#include "nrf24l01.h"


#endif
