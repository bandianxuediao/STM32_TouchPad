#ifndef __BSP_USART_H
#define __BSP_USART_H
#include "stdio.h"
#include "stm32f10x.h"


#define COMn                             3	/*������������*/
typedef enum 
{
  COM1 = 0,
  COM2 = 1,
  COM3 = 1,
} COM_TypeDef; 

void bsp_InitUart(COM_TypeDef COM,u32 UsartBaudRate);
void USART1_Send_Byte(uint16_t Data);
void USART_SendByte(USART_TypeDef* USARTx,uint8_t byte);
void USART_SendStr(USART_TypeDef* USARTx,const char * data);
void USART_SendArray(USART_TypeDef* USARTx,const u8 *data,u16 len);
uint8_t USART_ReceiveByte(USART_TypeDef* USARTx);


#endif
