#ifndef __HARDWARE_INIT_H
#define __HARDWARE_INIT_H

		   
#include "stm32f10x.h"
#include "bsp_delay.h"



#define  BUZZER_ON()    PBout(1) = 1;
#define  BUZZER_OFF()   PBout(1) = 0;
#define  BUZZER_ONCE()  PBout(1) =! PBout(1);


void  HardWare_Init(void);
void  Checki_Sys(void);



#endif





